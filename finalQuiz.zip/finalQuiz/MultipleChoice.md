MULTIPLE CHOICE



Question 1. What is Dependency Injection?





a.) A design pattern which implements Inversion of Control for software applications.



b.) One of the spring module.



c.) A technique to get dependencies of any project.



d.) Used to promote tight coupling in code.




ANSWER - A






Question 2. Repository is used for?



a.) Getting data from the Database





b.)Connect HTML with Java



c.)Store Vaiable



d.)None of the Above



ANSWER - C







Question 3. What is Bean in Spring?




a.) Component



b.) Object



c.) Class



d.) Container




ANSWER - B






Question 4. What are different types of Autowire?





a.) byName



b.) byType



c.) constructor



d.) autodetect



e.) All of the above



ANSWER - E





Question 5. What is default Web server used in Spring boot Application?






a.) Jetty



b.) Apache Tomcat



c.) JSP. 



ANSWER - B