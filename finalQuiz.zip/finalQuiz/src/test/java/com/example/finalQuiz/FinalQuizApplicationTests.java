package com.example.finalQuiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalQuizApplicationTests {

	@Test
	void contextLoads() {
	}

}
